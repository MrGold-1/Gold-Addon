package com.nnpg.glazed.modules.esp;

import com.nnpg.glazed.GlazedAddon;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.Renderer3D;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.network.MeteorExecutor;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.*;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class HoleTunnelStairsESP extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgHParams = settings.createGroup("Hole Parameters");
    private final SettingGroup sgTParams = settings.createGroup("Tunnel Parameters");
    private final SettingGroup sgSParams = settings.createGroup("Stairs Parameters");
    private final SettingGroup sgRender = settings.createGroup("Rendering");
    private final Setting<DetectionMode> detectionMode = sgGeneral.add(new EnumSetting.Builder<DetectionMode>()
        .name("Detection Mode")
        .description("Choose what to detect: holes, tunnels, stairs, or all.")
        .defaultValue(DetectionMode.ALL)
        .build()
    );
    private final Setting<Integer> maxChunks = sgGeneral.add(new IntSetting.Builder()
        .name("Chunks to process/tick")
        .description("Amount of Chunks to process per tick")
        .defaultValue(10)
        .min(1)
        .sliderRange(1, 100)
        .build()
    );
    private final Setting<Boolean> airBlocks = sgGeneral.add(new BoolSetting.Builder()
        .name("Detect only Air blocks as passable.")
        .description("Only marks tunnels or holes if their blocks are air as oppose to if the blocks are passable.")
        .defaultValue(false)
        .build()
    );
    private final Setting<Integer> minY = sgGeneral.add(new IntSetting.Builder()
        .name("Detection Y Minimum OffSet")
        .description("Scans blocks above or at this this many blocks from minimum build limit.")
        .min(0)
        .sliderRange(0,319)
        .defaultValue(0)
        .build()
    );
    private final Setting<Integer> maxY = sgGeneral.add(new IntSetting.Builder()
        .name("Detection Y Maximum OffSet")
        .description("Scans blocks below or at this this many blocks from maximum build limit.")
        .min(0)
        .sliderRange(0,319)
        .defaultValue(0)
        .build()
    );
    private final Setting<Integer> minHoleDepth = sgHParams.add(new IntSetting.Builder()
        .name("Min Hole Depth")
        .description("Minimum depth for a hole to be detected")
        .defaultValue(4)
        .min(1)
        .sliderMax(20)
        .build()
    );
    private final Setting<Integer> minTunnelLength = sgTParams.add(new IntSetting.Builder()
        .name("Min Tunnel Length")
        .description("Minimum length for a tunnel to be detected")
        .defaultValue(3)
        .min(1)
        .sliderMax(20)
        .build()
    );
    private final Setting<Integer> minTunnelHeight = sgTParams.add(new IntSetting.Builder()
        .name("Min Tunnel Height")
        .description("Minimum height of the tunnels to be detected")
        .defaultValue(2)
        .min(1)
        .sliderMax(10)
        .build()
    );
    private final Setting<Integer> maxTunnelHeight = sgTParams.add(new IntSetting.Builder()
        .name("Max Tunnel Height")
        .description("Maximum height of the tunnels to be detected")
        .defaultValue(3)
        .min(2)
        .sliderMax(10)
        .build()
    );
    private final Setting<Boolean> diagonals = sgTParams.add(new BoolSetting.Builder()
        .name("Detect Diagonal Tunnels.")
        .description("Detects diagonal tunnels when tunnels are selected to be detected.")
        .defaultValue(true)
        .build()
    );
    private final Setting<Integer> minDiagonalLength = sgTParams.add(new IntSetting.Builder()
        .name("Min Diagonal Tunnel Length")
        .description("Minimum length for diagonal tunnels to be detected")
        .defaultValue(3)
        .min(1)
        .sliderMax(20)
        .visible(diagonals::get)
        .build()
    );
    private final Setting<Integer> minDiagonalWidth = sgTParams.add(new IntSetting.Builder()
        .name("Min Diagonal Tunnel Width")
        .description("Minimum width for diagonal tunnels to be detected")
        .defaultValue(2)
        .min(2)
        .sliderMax(10)
        .visible(diagonals::get)
        .build()
    );
    private final Setting<Integer> maxDiagonalWidth = sgTParams.add(new IntSetting.Builder()
        .name("Max Diagonal Tunnel Width")
        .description("Maximum width for diagonal tunnels to be detected")
        .defaultValue(4)
        .min(2)
        .sliderMax(10)
        .visible(diagonals::get)
        .build()
    );
    private final Setting<Integer> minStaircaseLength = sgSParams.add(new IntSetting.Builder()
        .name("Min Staircase Length")
        .description("Minimum length for a staircase to be detected")
        .defaultValue(3)
        .min(1)
        .sliderMax(20)
        .build()
    );
    private final Setting<Integer> minStaircaseHeight = sgSParams.add(new IntSetting.Builder()
        .name("Min Staircase Height")
        .description("Minimum height of the staircase to be detected")
        .defaultValue(3)
        .min(2)
        .sliderMax(10)
        .build()
    );
    private final Setting<Integer> maxStaircaseHeight = sgSParams.add(new IntSetting.Builder()
        .name("Max Staircase Height")
        .description("Maximum height of the staircase to be detected")
        .defaultValue(5)
        .min(2)
        .sliderMax(10)
        .build()
    );
    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode")
        .description("How the shapes are rendered.")
        .defaultValue(ShapeMode.Both)
        .build()
    );
    private final Setting<SettingColor> holeLineColor = sgRender.add(new ColorSetting.Builder()
        .name("1x1-hole-line-color")
        .description("The color of the lines for 1x1 holes being rendered.")
        .defaultValue(new SettingColor(255, 0, 0, 95))
        .build()
    );
    private final Setting<SettingColor> holeSideColor = sgRender.add(new ColorSetting.Builder()
        .name("1x1-hole-side-color")
        .description("The color of the sides for 1x1 holes being rendered.")
        .defaultValue(new SettingColor(255, 0, 0, 30))
        .build()
    );
    private final Setting<SettingColor> hole3x1LineColor = sgRender.add(new ColorSetting.Builder()
        .name("3x1-hole-line-color")
        .description("The color of the lines for 3x1 holes being rendered.")
        .defaultValue(new SettingColor(255, 165, 0, 95))
        .build()
    );
    private final Setting<SettingColor> hole3x1SideColor = sgRender.add(new ColorSetting.Builder()
        .name("3x1-hole-side-color")
        .description("The color of the sides for 3x1 holes being rendered.")
        .defaultValue(new SettingColor(255, 165, 0, 30))
        .build()
    );
    private final Setting<SettingColor> tunnelLineColor = sgRender.add(new ColorSetting.Builder()
        .name("tunnel-line-color")
        .description("The color of the lines for the tunnels being rendered.")
        .defaultValue(new SettingColor(0, 0, 255, 95))
        .build()
    );
    private final Setting<SettingColor> tunnelSideColor = sgRender.add(new ColorSetting.Builder()
        .name("tunnel-side-color")
        .description("The color of the sides for the tunnels being rendered.")
        .defaultValue(new SettingColor(0, 0, 255, 30))
        .build()
    );
    private final Setting<SettingColor> staircaseLineColor = sgRender.add(new ColorSetting.Builder()
        .name("staircase-line-color")
        .description("The color of the lines for the staircases being rendered.")
        .defaultValue(new SettingColor(255, 0, 255, 95))
        .build()
    );
    private final Setting<SettingColor> staircaseSideColor = sgRender.add(new ColorSetting.Builder()
        .name("staircase-side-color")
        .description("The color of the sides for the staircases being rendered.")
        .defaultValue(new SettingColor(255, 0, 255, 30))
        .build()
    );

    private static final Direction[] DIRECTIONS = { Direction.EAST, Direction.WEST, Direction.NORTH, Direction.SOUTH };
    private final Long2ObjectMap<TChunk> chunks = new Long2ObjectOpenHashMap<>();
    private final Queue<Chunk> chunkQueue = new LinkedList<>();
    private final Set<Box> holes = Collections.newSetFromMap(new ConcurrentHashMap<>());
    private final Set<Box> tunnels = Collections.newSetFromMap(new ConcurrentHashMap<>());
    private final Set<Box> staircases = Collections.newSetFromMap(new ConcurrentHashMap<>());
    private final Set<Box> holes3x1 = Collections.newSetFromMap(new ConcurrentHashMap<>());

    public HoleTunnelStairsESP() {
        super(GlazedAddon.esp, "hole-tunnel-stair-esp", "Finds and highlights holes and tunnels and stairs.");
    }

    public Set<Box> getHoles() {
        return new HashSet<>(holes);
    }

    @Override
    public void onDeactivate() {
        chunks.clear();
        chunkQueue.clear();
        holes.clear();
        tunnels.clear();
        staircases.clear();
        holes3x1.clear();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        synchronized (chunks) {
            for (TChunk tChunk : chunks.values()) tChunk.marked = false;

            for (Chunk chunk : Utils.chunks(true)) {
                long key = ChunkPos.toLong(chunk.getPos().x, chunk.getPos().z);

                if (chunks.containsKey(key)) chunks.get(key).marked = true;
                else if (!chunkQueue.contains(chunk)) {
                    chunkQueue.add(chunk);
                }
            }

            processChunkQueue();
            chunks.values().removeIf(tChunk -> !tChunk.marked);
        }
        removeBoxesOutsideRenderDistance();
    }

    private void removeBoxesOutsideRenderDistance() {
        Set<WorldChunk> chunkSet = new HashSet<>();
        for (Chunk chunk : Utils.chunks(true)) {
            if (chunk instanceof WorldChunk) {
                chunkSet.add((WorldChunk) chunk);
            }
        }

        removeBoxesOutsideRenderDistance(holes, chunkSet);
        removeBoxesOutsideRenderDistance(tunnels, chunkSet);
        removeBoxesOutsideRenderDistance(staircases, chunkSet);
        removeBoxesOutsideRenderDistance(holes3x1, chunkSet);
    }

    private void removeBoxesOutsideRenderDistance(Set<Box> boxSet, Set<WorldChunk> worldChunks) {
        boxSet.removeIf(box -> {
            BlockPos boxPos = new BlockPos((int)Math.floor(box.getCenter().getX()), (int)Math.floor(box.getCenter().getY()), (int)Math.floor(box.getCenter().getZ()));
            assert mc.world != null;
            return !worldChunks.contains(mc.world.getChunk(boxPos));
        });
    }

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        switch (detectionMode.get()) {
            case ALL:
                renderHoles(event.renderer);
                renderTunnels(event.renderer);
                renderStaircases(event.renderer);
                render3x1Holes(event.renderer);
                break;
            case HOLES_AND_TUNNELS:
                renderHoles(event.renderer);
                renderTunnels(event.renderer);
                render3x1Holes(event.renderer);
                break;
            case HOLES_AND_STAIRCASES:
                renderHoles(event.renderer);
                renderStaircases(event.renderer);
                render3x1Holes(event.renderer);
                break;
            case TUNNELS_AND_STAIRCASES:
                renderTunnels(event.renderer);
                renderStaircases(event.renderer);
                break;
            case HOLES:
                renderHoles(event.renderer);
                render3x1Holes(event.renderer);
                break;
            case TUNNELS:
                renderTunnels(event.renderer);
                break;
            case STAIRCASES:
                renderStaircases(event.renderer);
                break;
            case HOLES_3X1_AND_TUNNELS:
                renderHoles(event.renderer);
                render3x1Holes(event.renderer);
                renderTunnels(event.renderer);
                break;
        }
    }

    private void renderHoles(Renderer3D renderer) {
        for (Box box : holes) {
            renderer.box(box.minX, box.minY, box.minZ, box.maxX, box.maxY, box.maxZ, holeSideColor.get(), holeLineColor.get(), shapeMode.get(), 0);
        }
    }

    private void render3x1Holes(Renderer3D renderer) {
        for (Box box : holes3x1) {
            renderer.box(box.minX, box.minY, box.minZ, box.maxX, box.maxY, box.maxZ, hole3x1SideColor.get(), hole3x1LineColor.get(), shapeMode.get(), 0);
        }
    }

    private void renderTunnels(Renderer3D renderer) {
        for (Box box : tunnels) {
            renderer.box(box.minX, box.minY, box.minZ, box.maxX, box.maxY, box.maxZ, tunnelSideColor.get(), tunnelLineColor.get(), shapeMode.get(), 0);
        }
    }

    private void renderStaircases(Renderer3D renderer) {
        for (Box box : staircases) {
            renderer.box(box.minX, box.minY, box.minZ, box.maxX, box.maxY, box.maxZ, staircaseSideColor.get(), staircaseLineColor.get(), shapeMode.get(), 0);
        }
    }

    private void processChunkQueue() {
        int maxChunksPerTick = maxChunks.get();
        int processed = 0;

        while (!chunkQueue.isEmpty() && processed < maxChunksPerTick) {
            Chunk chunk = chunkQueue.poll();
            if (chunk != null) {
                TChunk tChunk = new TChunk(chunk.getPos().x, chunk.getPos().z);
                chunks.put(tChunk.getKey(), tChunk);

                MeteorExecutor.execute(() -> searchChunk(chunk, tChunk));
                processed++;
            }
        }
    }

    private void searchChunk(Chunk chunk, TChunk tChunk) {
        var sections = chunk.getSectionArray();
        int Ymin = mc.world.getBottomY() + minY.get();
        int Ymax = mc.world.getTopYInclusive() - maxY.get();
        int Y = mc.world.getBottomY();
        for (ChunkSection section : sections) {
            if (section != null && !section.isEmpty()) {
                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        for (int y = 0; y < 16; y++) {
                            int currentY = Y + y;
                            if (currentY <= Ymin || currentY >= Ymax) continue;
                            BlockPos pos = chunk.getPos().getBlockPos(x, currentY, z);
                            if (isPassableBlock(pos)) {
                                switch (detectionMode.get()) {
                                    case ALL:
                                        checkHole(pos, holes);
                                        check3x1Hole(pos, holes3x1);
                                        checkTunnel(pos);
                                        if (diagonals.get()) checkDiagonalTunnel(pos);
                                        checkStaircase(pos);
                                        break;
                                    case HOLES_AND_TUNNELS:
                                        checkHole(pos, holes);
                                        check3x1Hole(pos, holes3x1);
                                        checkTunnel(pos);
                                        if (diagonals.get()) checkDiagonalTunnel(pos);
                                        break;
                                    case HOLES_AND_STAIRCASES:
                                        checkHole(pos, holes);
                                        check3x1Hole(pos, holes3x1);
                                        checkStaircase(pos);
                                        break;
                                    case TUNNELS_AND_STAIRCASES:
                                        checkTunnel(pos);
                                        if (diagonals.get()) checkDiagonalTunnel(pos);
                                        checkStaircase(pos);
                                        break;
                                    case HOLES:
                                        checkHole(pos, holes);
                                        check3x1Hole(pos, holes3x1);
                                        break;
                                    case TUNNELS:
                                        checkTunnel(pos);
                                        if (diagonals.get()) checkDiagonalTunnel(pos);
                                        break;
                                    case STAIRCASES:
                                        checkStaircase(pos);
                                        break;
                                    case HOLES_3X1_AND_TUNNELS:
                                        checkHole(pos, holes);
                                        check3x1Hole(pos, holes3x1);
                                        checkTunnel(pos);
                                        if (diagonals.get()) checkDiagonalTunnel(pos);
                                        break;
                                }
                            }
                        }
                    }
                }
            }
            Y += 16;
        }
    }

    private void checkHole(BlockPos pos, Set<Box> holes) {
        if (isValidHoleSection(pos)) {
            BlockPos.Mutable currentPos = pos.mutableCopy();
            while (isValidHoleSection(currentPos)) {
                currentPos.move(Direction.UP);
            }
            if (currentPos.getY() - pos.getY() >= minHoleDepth.get()) {
                Box holeBox = new Box(
                    pos.getX(), pos.getY(), pos.getZ(),
                    pos.getX() + 1, currentPos.getY(), pos.getZ() + 1
                );
                if (!holes.contains(holeBox) && holes.stream().noneMatch(existingHole -> existingHole.intersects(holeBox))) {
                    holes.add(holeBox);
                }
            }
        }
    }

    private void check3x1Hole(BlockPos pos, Set<Box> holes3x1) {
        // Check 3x1 hole in X direction (3 blocks east-west, 1 block north-south)
        if (isValid3x1HoleSectionX(pos)) {
            BlockPos.Mutable currentPos = pos.mutableCopy();
            while (isValid3x1HoleSectionX(currentPos)) {
                currentPos.move(Direction.UP);
            }
            if (currentPos.getY() - pos.getY() >= minHoleDepth.get()) {
                Box holeBox = new Box(
                    pos.getX(), pos.getY(), pos.getZ(),
                    pos.getX() + 3, currentPos.getY(), pos.getZ() + 1
                );
                if (!holes3x1.contains(holeBox) && holes3x1.stream().noneMatch(existingHole -> existingHole.intersects(holeBox))) {
                    holes3x1.add(holeBox);
                }
            }
        }

        // Check 3x1 hole in Z direction (1 block east-west, 3 blocks north-south)
        if (isValid3x1HoleSectionZ(pos)) {
            BlockPos.Mutable currentPos = pos.mutableCopy();
            while (isValid3x1HoleSectionZ(currentPos)) {
                currentPos.move(Direction.UP);
            }
            if (currentPos.getY() - pos.getY() >= minHoleDepth.get()) {
                Box holeBox = new Box(
                    pos.getX(), pos.getY(), pos.getZ(),
                    pos.getX() + 1, currentPos.getY(), pos.getZ() + 3
                );
                if (!holes3x1.contains(holeBox) && holes3x1.stream().noneMatch(existingHole -> existingHole.intersects(holeBox))) {
                    holes3x1.add(holeBox);
                }
            }
        }
    }

    private boolean isValidHoleSection(BlockPos pos) {
        return isPassableBlock(pos) && !isPassableBlock(pos.north()) && !isPassableBlock(pos.south()) && !isPassableBlock(pos.east()) && !isPassableBlock(pos.west());
    }

    private boolean isValid3x1HoleSectionX(BlockPos pos) {
        // Check if this is part of a 3x1 hole in X direction
        return isPassableBlock(pos) &&
            isPassableBlock(pos.east()) &&
            isPassableBlock(pos.east(2)) &&
            !isPassableBlock(pos.north()) &&
            !isPassableBlock(pos.south()) &&
            !isPassableBlock(pos.east(3)) &&
            !isPassableBlock(pos.west()) &&
            !isPassableBlock(pos.east().north()) &&
            !isPassableBlock(pos.east().south()) &&
            !isPassableBlock(pos.east(2).north()) &&
            !isPassableBlock(pos.east(2).south());
    }

    private boolean isValid3x1HoleSectionZ(BlockPos pos) {
        // Check if this is part of a 3x1 hole in Z direction
        return isPassableBlock(pos) &&
            isPassableBlock(pos.south()) &&
            isPassableBlock(pos.south(2)) &&
            !isPassableBlock(pos.east()) &&
            !isPassableBlock(pos.west()) &&
            !isPassableBlock(pos.south(3)) &&
            !isPassableBlock(pos.north()) &&
            !isPassableBlock(pos.south().east()) &&
            !isPassableBlock(pos.south().west()) &&
            !isPassableBlock(pos.south(2).east()) &&
            !isPassableBlock(pos.south(2).west());
    }

    private void checkTunnel(BlockPos pos) {
        for (Direction dir : DIRECTIONS) {
            BlockPos.Mutable currentPos = pos.mutableCopy();
            int stepCount = 0;
            BlockPos startPos = null;
            BlockPos endPos = null;
            int maxHeight = 0;
            if (startPos == null && isTunnelSection(currentPos, dir)) {
                startPos = currentPos.toImmutable();
            }
            while (isTunnelSection(currentPos, dir)) {
                maxHeight = Math.max(maxHeight, getTunnelHeight(currentPos));
                endPos = currentPos.toImmutable();
                currentPos.move(dir);
                stepCount++;
            }

            if (stepCount >= minTunnelLength.get() && maxHeight >= minTunnelHeight.get() && maxHeight <= maxTunnelHeight.get()) {
                Box tunnelBox = new Box(
                    Math.min(startPos.getX(), endPos.getX()),
                    startPos.getY(),
                    Math.min(startPos.getZ(), endPos.getZ()),
                    Math.max(startPos.getX(), endPos.getX()) + 1,
                    startPos.getY() + maxHeight,
                    Math.max(startPos.getZ(), endPos.getZ()) + 1
                );

                if (!tunnels.contains(tunnelBox) && tunnels.stream().noneMatch(existingTunnel -> existingTunnel.intersects(tunnelBox))) {
                    tunnels.add(tunnelBox);
                }
            }
        }
    }

    private boolean isTunnelSection(BlockPos pos, Direction dir) {
        int height = getTunnelHeight(pos);
        if (height < minTunnelHeight.get() || height > maxTunnelHeight.get()) return false;
        if (isPassableBlock(pos.down()) || isPassableBlock(pos.up(height))) return false;
        Direction[] perpDirs = dir.getAxis() == Direction.Axis.X ? new Direction[]{Direction.NORTH, Direction.SOUTH} : new Direction[]{Direction.EAST, Direction.WEST};
        for (Direction perpDir : perpDirs) {
            for (int i = 0; i < height; i++) {
                if (isPassableBlock(pos.up(i).offset(perpDir))) {
                    return false;
                }
            }
        }
        return true;
    }

    private void checkDiagonalTunnel(BlockPos pos) {
        for (Direction dir : DIRECTIONS) {
            for (int i = minDiagonalWidth.get() - 1; i < maxDiagonalWidth.get(); i++) {
                BlockPos.Mutable currentPos = pos.mutableCopy();
                int stepCount = 0;
                List<Box> potentialBoxes = new ArrayList<>();

                Direction checkingDir = dir;
                boolean turnRight = true;

                while (isDiagonalTunnelSection(currentPos, checkingDir)) {
                    int height = getTunnelHeight(currentPos);
                    Box tunnelBox = new Box(
                        currentPos.getX(),
                        currentPos.getY(),
                        currentPos.getZ(),
                        currentPos.getX() + 1,
                        currentPos.getY() + height,
                        currentPos.getZ() + 1
                    );
                    if (!potentialBoxes.contains(tunnelBox) && !potentialBoxes.stream().anyMatch(existingDiagonal -> existingDiagonal.intersects(tunnelBox))) {
                        potentialBoxes.add(tunnelBox);
                    }

                    if (turnRight) {
                        checkingDir = checkingDir.rotateYClockwise();
                        currentPos.move(checkingDir.rotateYClockwise(), i);
                        turnRight = false;
                    } else {
                        checkingDir = checkingDir.rotateYCounterclockwise();
                        currentPos.move(checkingDir.rotateYCounterclockwise(), i);
                        turnRight = true;
                    }
                    stepCount++;
                }

                if (stepCount / minDiagonalWidth.get() >= minDiagonalLength.get()) {
                    potentialBoxes.forEach(potentialBox -> {
                        if (!tunnels.contains(potentialBox) && tunnels.stream().noneMatch(existingDiagonal -> existingDiagonal.intersects(potentialBox))) {
                            tunnels.add(potentialBox);
                        }
                    });
                }
            }
        }
    }

    private boolean isDiagonalTunnelSection(BlockPos pos, Direction dir) {
        int height = getTunnelHeight(pos);
        if (height < minTunnelHeight.get() || height > maxTunnelHeight.get()) return false;
        if (isPassableBlock(pos.down()) || isPassableBlock(pos.up(height))) return false;

        boolean wasPassableBlockFound = false;
        for (int i = 0; i < height; i++) {
            if (isPassableBlock(pos.up(i).offset(dir))) wasPassableBlockFound = true;
        }
        if (wasPassableBlockFound) return false;

        return true;
    }

    private int getTunnelHeight(BlockPos pos) {
        int height = 0;
        while (isPassableBlock(pos.up(height)) && height < maxTunnelHeight.get()) {
            height++;
        }
        return height;
    }

    private void checkStaircase(BlockPos pos) {
        for (Direction dir : DIRECTIONS) {
            BlockPos.Mutable currentPos = pos.mutableCopy();
            int stepCount = 0;
            List<Box> potentialStaircaseBoxes = new ArrayList<>();

            while (isStaircaseSection(currentPos, dir)) {
                int height = getStaircaseHeight(currentPos);
                Box stairsBox = new Box(
                    currentPos.getX(),
                    currentPos.getY(),
                    currentPos.getZ(),
                    currentPos.getX() + 1,
                    currentPos.getY() + height,
                    currentPos.getZ() + 1
                );
                if (!potentialStaircaseBoxes.contains(stairsBox) && !potentialStaircaseBoxes.stream().anyMatch(existingStaircase -> existingStaircase.intersects(stairsBox))) {
                    potentialStaircaseBoxes.add(stairsBox);
                }
                currentPos.move(dir);
                currentPos.move(Direction.UP);
                stepCount++;
            }

            for (Box stairsBox : potentialStaircaseBoxes) {
                if (stepCount >= minStaircaseLength.get() && !staircases.contains(stairsBox) && !staircases.stream().anyMatch(existingStaircase -> existingStaircase.intersects(stairsBox))) {
                    staircases.add(stairsBox);
                }
            }
        }
    }

    private int getStaircaseHeight(BlockPos pos) {
        int height = 0;
        while (isPassableBlock(pos.up(height)) && height < maxStaircaseHeight.get()) {
            height++;
        }
        return height;
    }

    private boolean isStaircaseSection(BlockPos pos, Direction dir) {
        int height = getStaircaseHeight(pos);
        if (height < minStaircaseHeight.get() || height > maxStaircaseHeight.get()) return false;
        if (isPassableBlock(pos.down()) || isPassableBlock(pos.up(height))) return false;
        Direction[] perpDirs = dir.getAxis() == Direction.Axis.X ? new Direction[]{Direction.NORTH, Direction.SOUTH} : new Direction[]{Direction.EAST, Direction.WEST};
        for (Direction perpDir : perpDirs) {
            for (int i = 0; i < height; i++) {
                if (isPassableBlock(pos.up(i).offset(perpDir))) {
                    return false;
                }
            }
        }
        return true;
    }

    private boolean isPassableBlock(BlockPos pos) {
        BlockState state = mc.world.getBlockState(pos);
        if (airBlocks.get()) {
            return state.isAir();
        } else {
            VoxelShape shape = state.getCollisionShape(mc.world, pos);
            return shape.isEmpty() || !VoxelShapes.fullCube().equals(shape);
        }
    }

    public enum DetectionMode {
        ALL,
        HOLES_AND_TUNNELS,
        HOLES_AND_STAIRCASES,
        TUNNELS_AND_STAIRCASES,
        HOLES,
        TUNNELS,
        STAIRCASES,
        HOLES_3X1_AND_TUNNELS
    }

    private class TChunk {
        private final int x, z;
        public boolean marked;

        public TChunk(int x, int z) {
            this.x = x;
            this.z = z;
            this.marked = true;
        }

        public long getKey() {
            return ChunkPos.toLong(x, z);
        }
    }
}
